<!DOCTYPE html>
<html>
<head>
    <title>Kopiding.in</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
<h1>Selamat Datang di Kopiding.in!</h1>   
<div class="container">
    <?php echo $__env->yieldContent('konten'); ?>
</div>
   
</body>
</html><?php /**PATH C:\xampp\htdocs\project_fia\resources\views/users/layout.blade.php ENDPATH**/ ?>