@extends('users.layout')
 
@section('konten')
  @if(session()->get('success'))
    <div class="alert alert-success">
      {{ session()->get('success') }}  
    </div><br/>
  @endif
  <h1>Selamat Datang di CRUD Laravel 6</h1>
  <a href="{{ route('users.create')}}" class="btn btn-primary">Tambah</a></td><br><br>
  <table class="table table-striped border text-center">
    <thead>
        <tr>
          <td>ID</td>
          <td>Product Name</td>
          <td>Product Description</td>
          <td>Product Price</td>
          <td>Product Qty</td>
          <td colspan="2">Kelola Data</td>
        </tr>
    </thead>
    <tbody>
    @foreach($users as $user)
      <tr>
          <td>{{$user->id_barang}}</td>
          <td>{{$user->nama_barang}}</td>
          <td>{{$user->desc_barang}}</td>
          <td>{{$user->harga_barang}}</td>
          <td>{{$user->stok_barang}}</td>
          <td><a href="{{ route('users.edit', $user->id_barang)}}" class="btn btn-warning">Edit</a></td> // tambah code berikut
          <td>
             <form action="{{ route('users.destroy', $user->id_barang)}}" method="post">
                 @csrf
                 @method('DELETE')
                <button class="btn btn-danger" type="submit">Delete</button>
            </form>
         </td>
      </tr>
      @endforeach
    </tbody>
  </table>
@endsection