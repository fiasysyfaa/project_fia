@extends('users.layout')

@section('konten')
<div class="card uper">
  <div class="card-header">
    Form Tambah Data
  </div>
  <div class="card-body">
    @if ($errors->any())
      <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
              <li>{{ $error }}</li>
            @endforeach
        </ul>
      </div><br/>
    @endif
      <form method="post" action="{{ route('users.store') }}">
        @csrf
          <div class="form-group"> 
              <label>ID</label>
              <input type="text" class="form-control" name="id_barang"/>
          </div>
          <div class="form-group">
              <label>Product Name</label>
              <input type="nama_barang" class="form-control" name="nama_barang"/>
          </div>
          <div class="form-group">
              <label>Product Description</label>
              <input type="desc_barang" class="form-control" name="desc_barang"/>
          </div>
          <div class="form-group">
              <label>Product Price</label>
              <input type="harga_barang" class="form-control" name="harga_barang"/>
          </div>
          <div class="form-group">
              <label>Product Qty</label>
              <input type="stok_barang" class="form-control" name="stok_barang"/>
          </div>
          <button type="submit" class="btn btn-primary">Tambah Data</button>
      </form>
      <a href="{{ route('users.create')}}" class="btn btn-primary">Tambah Data</a>
  </div>
</div>
@endsection