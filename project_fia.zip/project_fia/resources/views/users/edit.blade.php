@extends('users.layout')
   
@section('konten')
<div class="card uper">
  <div class="card-header">
    Form Edit Data
  </div>
  <div class="card-body">
    @if ($errors->any())
      <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
              <li>{{ $error }}</li>
            @endforeach
        </ul>
      </div><br/>
    @endif
  
    <form action="{{ route('users.update',$user->id_barang) }}" method="POST">
        @csrf
        @method('PUT')
   
            <div class="form-group"> 
              <label>ID</label>
              <input type="text" class="form-control" name="nama" value="{{ $user->id_barang }}"/>
          </div>
          <div class="form-group">
              <label>Product Name</label>
              <input type="nama_barang" class="form-control" name="email" value="{{ $user->nama_barang }}"/>
          </div>
          <div class="form-group">
              <label>Product Description</label>
              <input type="desc_barang" class="form-control" name="tempat_lahir" value="{{ $user->desc_barang }}"/>
          </div>
          <div class="form-group">
              <label>Product Price</label>
              <input type="harga_barang" class="form-control" name="tanggal_lahir" value="{{ $user->harga_barang}}"/>
          </div>
          <div class="form-group">
              <label>Product Qty</label>
              <input type="stok_barang" class="form-control" name="tanggal_lahir" value="{{ $user->stok_barang}}"/>
          </div>
            <button type="submit" class="btn btn-primary">Edit Data</button>
        </div>
   
    </form>
  </div>
</div>
@endsection