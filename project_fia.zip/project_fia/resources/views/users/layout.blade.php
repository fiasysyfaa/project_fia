<!DOCTYPE html>
<html>
<head>
    <title>CRUD Laravel 6 Kopiding.in</title>
    <link rel="stylesheet" href="{{asset('bootstrap.min.css')}}">
</head>
<body>
<h1>Selamat Datang di Kopiding.in!</h1> 
<div class="container">
    @yield('konten')
</div>
</body>
</html>